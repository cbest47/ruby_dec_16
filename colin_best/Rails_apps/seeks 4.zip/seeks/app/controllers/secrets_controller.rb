class SecretsController < ApplicationController
  def new
    @secret = Secret.new
  end

  def create

    @secret = Secret.create(secret_params)
    if @secret.errors.any?
      flash[:errors] = @secret.errors.full_messages
      redirect_to new_secret_path
    else
      redirect_to users_path
    end
  end

  private

  def secret_params
    params.require(:secret).permit(:content, :user_id )
  end

end
