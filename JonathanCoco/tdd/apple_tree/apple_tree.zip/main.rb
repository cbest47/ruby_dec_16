load 'apple_tree.rb'

apple_tree = AppleTree.new

apple_tree.year_gone_by()
apple_tree.year_gone_by()
apple_tree.year_gone_by()
apple_tree.year_gone_by()
apple_tree.year_gone_by()
apple_tree.year_gone_by()

apple_tree.grow()
apple_tree.grow()
apple_tree.grow()

puts  apple_tree.apple_count

apple_tree.pick_apples()

puts apple_tree.apple_count
